# AI Options Trading Assistant

A small FastAPI cloud app for conditional options analysis. Designed to be uploaded to GitHub from an Android phone and deployed on a compatible Python host.

## Important limitations
- This project does **not** include a live NSE/BSE/XAUUSD options data subscription or a broker connection.
- It does not generate a premium from the underlying index. You must provide genuine OHLC candles and the actual option premium from a lawful market-data provider.
- Until a real feed is connected, the app is a prototype that accepts manually supplied data. Do not treat a sample or stale quote as live.
- Free hosting plans can sleep, restart, impose usage limits, or change. This is not guaranteed 24/7 monitoring.
- No broker order placement is implemented.

## Deploy
1. Push all files in this folder to your GitHub repository.
2. Create a Python web service on a hosting provider that supports GitHub deploys.
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
5. Health check: `/health`
6. Open `/docs` to test the API.

`render.yaml` is included as a deployment template. Review the host's current free-plan limits before deploying.

## API workflow
`POST /api/market-snapshot` with JSON:
```json
{
  "symbol": "NIFTY",
  "spot": 25100,
  "option_side": "CE",
  "option_symbol": "NIFTY 25xxx CE",
  "expiry": "YYYY-MM-DD",
  "strike": 25100,
  "premium": 120.5,
  "lot_size": 1,
  "timestamp": "2026-11-14T10:00:00+05:30",
  "candles": [
    {"time":"09:15","open":25000,"high":25020,"low":24990,"close":25010,"volume":1000}
  ]
}
```
At least 30 candles are required. The sample above shows the structure only; add 30 or more real candles.
Then call `POST /api/analyze`.

## Risk settings
Defaults: ₹2,300 daily loss ceiling, 2 trades/day, ₹500 planned risk/trade. These are configurable at `PUT /api/settings`. This is a simple prototype risk gate, not a complete portfolio risk manager. The in-memory trade log resets when the service restarts; add a persistent database before relying on it.

## Safety
The engine only emits a conditional setup when the supplied option side matches a trend + breakout condition. It outputs WAIT when data is missing or conditions are not met. Stop and targets are illustrative fixed-percentage / R-multiple calculations and require validation against the contract's liquidity, spread, volatility and actual execution price.
