from datetime import datetime, date
from typing import Optional, Literal
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from .engine import build_signal
from .state import state

app = FastAPI(title="AI Options Trading Assistant", version="1.0.0",
              description="Conditional analysis engine. Not a broker and does not place orders.")

class Candle(BaseModel):
    time: str
    open: float
    high: float
    low: float
    close: float
    volume: float = 0

class Snapshot(BaseModel):
    symbol: Literal["NIFTY", "BANKNIFTY", "SENSEX", "XAUUSD"]
    spot: float = Field(gt=0)
    candles: list[Candle] = Field(min_length=30, max_length=500)
    option_side: Optional[Literal["CE", "PE"]] = None
    option_symbol: Optional[str] = None
    expiry: Optional[str] = None
    strike: Optional[float] = None
    premium: Optional[float] = Field(default=None, gt=0)
    lot_size: int = Field(default=1, ge=1)
    timestamp: Optional[str] = None

class Settings(BaseModel):
    max_daily_loss_inr: float = Field(default=2300, gt=0)
    max_trades_per_day: int = Field(default=2, ge=1, le=20)
    risk_per_trade_inr: float = Field(default=500, gt=0)
    premium_stop_pct: float = Field(default=15, gt=1, le=50)
    target_r_multiples: list[float] = [1.0, 2.0, 3.0]

app_state = {"snapshot": None, "settings": Settings(), "trades_today": 0,
             "daily_pnl": 0.0, "last_signal": None}

@app.get("/", response_class=HTMLResponse)
def home():
    with open("app/static/index.html", encoding="utf-8") as f:
        return f.read()

@app.get("/health")
def health():
    return {"status": "ok", "time_utc": datetime.utcnow().isoformat() + "Z"}

@app.get("/api/settings")
def get_settings():
    return app_state["settings"].model_dump()

@app.put("/api/settings")
def set_settings(settings: Settings):
    app_state["settings"] = settings
    return {"saved": True, "settings": settings.model_dump()}

@app.post("/api/market-snapshot")
def receive_snapshot(snapshot: Snapshot):
    # Supply candles and the actual option premium from a legitimate data source.
    app_state["snapshot"] = snapshot
    return {"accepted": True, "symbol": snapshot.symbol, "timestamp": snapshot.timestamp}

@app.post("/api/analyze")
def analyze():
    snap = app_state["snapshot"]
    if snap is None:
        raise HTTPException(400, "No market snapshot. POST candles and the actual option premium to /api/market-snapshot.")
    settings = app_state["settings"]
    result = build_signal(snap.model_dump(), settings.model_dump(),
                          app_state["trades_today"], app_state["daily_pnl"])
    app_state["last_signal"] = result
    return result

@app.get("/api/status")
def status():
    snap = app_state["snapshot"]
    return {
        "snapshot_loaded": snap is not None,
        "symbol": snap.symbol if snap else None,
        "snapshot_time": snap.timestamp if snap else None,
        "trades_today": app_state["trades_today"],
        "daily_pnl_inr": app_state["daily_pnl"],
        "last_signal": app_state["last_signal"]
    }

@app.post("/api/trade-log")
def trade_log(realized_pnl_inr: float):
    # Log only after a trade is closed; resets are manual at start of a new trading day.
    app_state["trades_today"] += 1
    app_state["daily_pnl"] += realized_pnl_inr
    return {"trades_today": app_state["trades_today"], "daily_pnl_inr": app_state["daily_pnl"]}

@app.post("/api/reset-day")
def reset_day():
    app_state["trades_today"] = 0
    app_state["daily_pnl"] = 0.0
    return {"reset": True}

@app.get("/api/last-signal")
def last_signal():
    return app_state["last_signal"] or {"status": "WAIT", "reason": "No analysis run yet."}
