def ema(values, period):
    alpha = 2 / (period + 1)
    result = values[0]
    for value in values[1:]:
        result = alpha * value + (1 - alpha) * result
    return result

def rsi(values, period=14):
    gains, losses = [], []
    for i in range(1, len(values)):
        change = values[i] - values[i-1]
        gains.append(max(change, 0))
        losses.append(max(-change, 0))
    avg_gain = sum(gains[-period:]) / min(period, len(gains))
    avg_loss = sum(losses[-period:]) / min(period, len(losses))
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def build_signal(s, cfg, trades_today, daily_pnl):
    candles = s["candles"]
    closes = [float(c["close"]) for c in candles]
    highs = [float(c["high"]) for c in candles]
    lows = [float(c["low"]) for c in candles]
    last = closes[-1]
    e9, e20, e50 = ema(closes[-50:], 9), ema(closes[-50:], 20), ema(closes[-50:], 50)
    current_rsi = rsi(closes)
    prev_high, prev_low = max(highs[-21:-1]), min(lows[-21:-1])
    trend = "BULLISH" if e9 > e20 > e50 else "BEARISH" if e9 < e20 < e50 else "NEUTRAL"
    breakout_up = last > prev_high
    breakout_down = last < prev_low
    reasons = [f"EMA9={e9:.2f}, EMA20={e20:.2f}, EMA50={e50:.2f}",
               f"RSI14={current_rsi:.1f}", f"20-candle high={prev_high:.2f}, low={prev_low:.2f}"]

    if daily_pnl <= -cfg["max_daily_loss_inr"]:
        return {"status":"BLOCKED", "reason":"Daily loss limit reached.", "metrics":reasons}
    if trades_today >= cfg["max_trades_per_day"]:
        return {"status":"BLOCKED", "reason":"Maximum trades for today reached.", "metrics":reasons}
    if s.get("premium") is None:
        return {"status":"WAIT", "reason":"Actual option premium is missing. Do not estimate it from the index price.",
                "bias":trend, "spot":s["spot"], "metrics":reasons}
    if trend == "BULLISH" and breakout_up and 50 <= current_rsi <= 75:
        side = "CE"
    elif trend == "BEARISH" and breakout_down and 25 <= current_rsi <= 50:
        side = "PE"
    else:
        return {"status":"WAIT", "reason":"No confirmed trend + breakout combination.", "bias":trend,
                "spot":s["spot"], "metrics":reasons}

    if s.get("option_side") != side:
        return {"status":"WAIT", "reason":f"Underlying setup suggests {side}, but supplied contract side does not match. Verify contract.",
                "suggested_side":side, "bias":trend, "spot":s["spot"], "metrics":reasons}
    entry = float(s["premium"])
    stop_pct = cfg["premium_stop_pct"] / 100
    stop = entry * (1 - stop_pct)
    risk_per_unit = entry - stop
    qty = int(cfg["risk_per_trade_inr"] / (risk_per_unit * int(s["lot_size"])))
    qty = max(0, qty)
    if qty < 1:
        return {"status":"WAIT", "reason":"One lot exceeds configured risk per trade. Reduce risk or do not trade.",
                "entry_premium":round(entry,2), "stop_loss":round(stop,2), "metrics":reasons}
    targets = [round(entry + risk_per_unit * r, 2) for r in cfg["target_r_multiples"]]
    return {
        "status":"CONDITIONAL_SETUP", "action":f"BUY {side}",
        "symbol":s["symbol"], "contract":s.get("option_symbol"), "expiry":s.get("expiry"),
        "strike":s.get("strike"), "spot":s["spot"], "entry_premium":round(entry,2),
        "stop_loss_premium":round(stop,2), "targets_premium":targets,
        "lot_size":s["lot_size"], "lots":qty,
        "max_planned_loss_inr":round((entry-stop)*s["lot_size"]*qty,2),
        "invalidation":f"Spot closes back inside breakout range; setup is invalid.",
        "bias":trend, "metrics":reasons,
        "warning":"Conditional educational analysis, not a guaranteed signal. Confirm live quotes, spread, liquidity and contract details before acting."
    }
